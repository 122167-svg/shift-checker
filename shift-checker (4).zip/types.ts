
export interface Shift {
  person: string;
  event: string;
  day: string;
  time: string;
  role?: string;
}
